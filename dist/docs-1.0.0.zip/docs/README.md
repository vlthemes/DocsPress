# DocsPress
This is the knowledge base documentation theme for WordPress.

## Development
* `gulp` - start files watcher
* `gulp build` - create build

## Contributions
If you have anything to fix or details to add, first file an issue on GitHub to see if it is likely to be accepted, then file a pull request with your change (one PR per issue).

## Credits
Based on plugins by [_nk](https://github.com/nk-o/)
