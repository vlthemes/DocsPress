<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

?>

<article <?php post_class( 'vlt-page' ); ?>>

	<div class="vlt-content-markup">
		<?php the_content(); ?>
	</div>

</article>
<!-- /.vlt-page -->