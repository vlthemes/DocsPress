<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

?>

<header class="vlt-page-title">

	<h1><?php the_title(); ?></h1>

	<a href="javascript:window.print()" class="vlt-btn vlt-btn--secondary"><i class="ri-printer-line left"></i><?php esc_html_e( 'Print Page', 'docspress' ); ?></a>

</header>
<!-- /.vlt-page-title -->