<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

?>

<header class="vlt-page-title">

	<h1><i class="ri-folder-line"></i><?php esc_html_e( 'Search Results', 'docspress' ); ?></h1>
	<a href="#" class="vlt-btn vlt-btn--secondary btn-go-back"><?php esc_html_e( 'Go Back', 'docspress' ); ?></a>

</header>
<!-- /.vlt-page-title -->