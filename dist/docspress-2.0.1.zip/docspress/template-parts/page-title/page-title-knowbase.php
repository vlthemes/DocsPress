<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

?>

<header class="vlt-page-title">

	<h1><i class="ri-folder-line"></i><?php echo docspress_get_theme_mod( 'knowbase_category_title' ) ? docspress_get_theme_mod( 'knowbase_category_title' ) : get_the_title(); ?></h1>

</header>
<!-- /.vlt-page-title -->
