<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

/**
 * TGM
 */
require_once DOCSPRESS_REQUIRE_DIRECTORY . 'inc/helper/class-tgm-plugin-activation.php';

/**
 * Breadcrumbs
 */
require_once DOCSPRESS_REQUIRE_DIRECTORY . 'inc/helper/breadcrumbs.php';