<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

$priority = 0;

/**
 * Knowbase options
 */
VLT_Options::add_field( array(
	'type' => 'text',
	'settings' => 'knowbase_category_title',
	'section' => 'section_knowbase',
	'label' => esc_html__( 'Category Title', 'docspress' ),
	'priority' => $priority++,
	'default' => '',
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'knowbase_search_form',
	'section' => 'section_knowbase',
	'label' => esc_html__( 'Search Form', 'docspress' ),
	'priority' => $priority++,
	'choices' => array(
		'show' => esc_html__( 'Show', 'docspress' ),
		'hide' => esc_html__( 'Hide', 'docspress' )
	),
	'default' => 'show',
) );

VLT_Options::add_field( array(
	'type' => 'number',
	'settings' => 'knowbase_category_count',
	'section' => 'section_knowbase',
	'label' => esc_html__( 'Number of Categories', 'docspress' ),
	'priority' => $priority++,
	'choices' => [
		'min' => 1,
		'max' => 999,
		'step' => 1,
	],
	'default' => 3,
) );

/**
 * Docs
 */
VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'show_share_docs',
	'section' => 'section_docs',
	'label' => esc_html__( 'Doc Share', 'docspress' ),
	'priority' => $priority++,
	'choices' => array(
		'show' => esc_html__( 'Show', 'docspress' ),
		'hide' => esc_html__( 'Hide', 'docspress' )
	),
	'default' => 'hide',
) );

/**
 * Changelog
 */
VLT_Options::add_field( array(
	'type' => 'text',
	'settings' => 'changelog_title',
	'section' => 'section_changelog',
	'label' => esc_html__( 'Page Title', 'docspress' ),
	'priority' => $priority++,
	'default' => esc_html__( 'Changelogs', 'docspress' ),
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'changelog_search_form',
	'section' => 'section_changelog',
	'label' => esc_html__( 'Search Form', 'docspress' ),
	'priority' => $priority++,
	'choices' => array(
		'show' => esc_html__( 'Show', 'docspress' ),
		'hide' => esc_html__( 'Hide', 'docspress' )
	),
	'default' => 'show',
) );