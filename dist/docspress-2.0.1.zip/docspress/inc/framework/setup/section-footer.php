<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

$priority = 0;

VLT_Options::add_field( array(
	'type' => 'custom',
	'settings' => 'sfg_1',
	'section' => 'section_footer_general',
	'default' => '<div class="kirki-separator">' . esc_html__( 'General', 'docspress' ) . '</div>',
	'priority' => $priority++,
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'footer_show',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Footer Show', 'docspress' ),
	'priority' => $priority++,
	'choices' => array(
		'show' => esc_html__( 'Show', 'docspress' ),
		'hide' => esc_html__( 'Hide', 'docspress' ),
	),
	'default' => 'hide',
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'footer_template',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Footer Template', 'docspress' ),
	'priority' => $priority++,
	'choices' => docspress_get_elementor_templates(),
	'active_callback' => array(
		array(
			'setting' => 'footer_show',
			'operator' => '==',
			'value' => 'show'
		),
	)
) );
