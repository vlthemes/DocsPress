<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

/**
 * Fallback menu
 */
if ( ! function_exists( 'docspress_fallback_menu' ) ) {
	function docspress_fallback_menu() {
		if ( current_user_can( 'administrator' ) ) {
			echo '<p class="vlt-no-menu-message">' . esc_html__( 'Please register navigation from', 'docspress' ) . ' ' . '<a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" target="_blank">' . esc_html__( 'Appearance > Menus', 'docspress' ) . '</a></p>';
		}
	}
}

/**
 * Nav breakpoint
 */
if ( ! function_exists( 'docspress_nav_breakpoint' ) ) {
	function docspress_nav_breakpoint() {
		return apply_filters('docspress/nav_breakpoint', 'xl');
	}
}