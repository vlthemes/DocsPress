<?php

/**
 * @author: VLThemes
 * @version: 2.0.1
 */

if ( is_active_sidebar( 'blog_sidebar' ) ) {
	dynamic_sidebar( 'blog_sidebar' );
}