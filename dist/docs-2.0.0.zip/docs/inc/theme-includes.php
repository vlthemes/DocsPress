<?php

/**
 * @author: VLThemes
 * @version: 2.0.0
 */

/**
 * TGM
 */
require_once DOCS_REQUIRE_DIRECTORY . 'inc/helper/class-tgm-plugin-activation.php';

/**
 * Breadcrumbs
 */
require_once DOCS_REQUIRE_DIRECTORY . 'inc/helper/breadcrumbs.php';