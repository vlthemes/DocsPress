<?php

/**
 * @author: VLThemes
 * @version: 2.0.0
 */

/**
 * Add body class
 */
if ( ! function_exists( 'docs_add_body_class' ) ) {
	function docs_add_body_class( $classes ) {

		$classes[] = '';
		if ( ! wp_is_mobile() ) {
			$classes[] = 'no-mobile';
		} else {
			$classes[] = 'is-mobile';
		}
		return $classes;

	}
}
add_filter( 'body_class', 'docs_add_body_class' );

/**
 * Remove comment notes
 */
add_filter( 'comment_form_logged_in', '__return_empty_string' );

/**
 * Get post password form
 */
if ( ! function_exists( 'docs_get_post_password_form' ) ) {
	function docs_get_post_password_form() {

		global $post;
		$label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
		$output = '<form class="vlt-post-password-form" action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">';
		$output .= '<p>' . esc_html__( 'This content is restricted access, please type the password below and get access.', 'docs' ) . '</p>';
		$output .= '<div class="vlt-form-group">';
		$output .= '<input name="post_password" id="' . $label . '" type="password" size="20" placeholder="' . esc_attr__( 'Password:' , 'docs' ) . '" class="vlt-border-white">';
		$output .= '</div>';
		$output .= '<button class="vlt-btn vlt-btn--primary">' . esc_attr__( 'Get Access' , 'docs' ) . '</button>';
		$output .= '</form>';
		return apply_filters( 'docs/get_post_password_form', $output );

	}
}
add_filter( 'the_password_form', 'docs_get_post_password_form' );

/**
 * Admin logo link
 */
if ( ! function_exists( 'docs_change_admin_logo_link' ) ) {
	function docs_change_admin_logo_link() {

		return home_url( '/' );

	}
}
add_filter( 'login_headerurl', 'docs_change_admin_logo_link' );

/**
 * Remove cf7 autop
 */
add_filter( 'wpcf7_autop_or_not', '__return_false' );

/*
 * Replace content variables
 */
if ( ! function_exists( 'docs_replace_content_variables' ) ) {
	function docs_replace_content_variables( $text ) {
		global $post;
		$replace = array(
			'%product_name%' => docs_get_field( 'product_name', wp_get_post_parent_id( $post->ID ) ),
			'%product_child_name%' => docs_get_field( 'product_child_name', wp_get_post_parent_id( $post->ID ) ),
			'%product_slug%' => docs_get_field( 'product_slug', wp_get_post_parent_id( $post->ID ) ),
		);
		$text = str_replace( array_keys( $replace ), $replace, $text );
		return $text;
	}
}
add_filter( 'the_content', 'docs_replace_content_variables' );
add_filter( 'the_excerpt', 'docs_replace_content_variables' );
add_filter( 'docs/get_trimmed_content', 'docs_replace_content_variables' );