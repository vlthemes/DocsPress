<?php

/**
 * @author: VLThemes
 * @version: 2.0.0
 */

$priority = 0;

/**
 * Footer general
 */
VLT_Options::add_field( array(
	'type' => 'editor',
	'settings' => 'footer_copyright',
	'section' => 'section_footer_options',
	'label' => esc_html__( 'Copyright', 'docs' ),
	'priority' => $priority++,
	'default' => '<p>© %s DocsPress. All rights reserved.</p>',
) );