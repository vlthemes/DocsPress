<?php

/**
 * @author: VLThemes
 * @version: 2.0.0
 */

$portfolio_link = docs_get_theme_mod( 'portfolio_link' );

?>

<div class="d-none d-lg-block">

	<header class="vlt-header vlt-header--default">

		<a class="vlt-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php if ( docs_get_theme_mod( 'header_logo' ) ) : ?>
				<span class="vlt-logo__icon">
					<img src="<?php echo docs_get_theme_mod( 'header_logo' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
				</span>
			<?php endif; ?>
			<span class="vlt-logo__description">
				<span><?php bloginfo( 'name' ); ?></span>
				<span><?php bloginfo( 'description' ); ?></span>
			<span>
		</a>
		<!-- /.vlt-logo -->

		<nav class="vlt-default-navigation">

			<?php
				wp_nav_menu( array(
					'theme_location' => 'primary-menu',
					'container' => false,
					'depth' => 3,
					'menu_class' => 'sf-menu',
					'fallback_cb' => 'docs_fallback_menu'
				) );
			?>

		</nav>
		<!-- /.vlt-default-navigation -->

		<?php if ( is_active_sidebar( 'subscribe_popup_sidebar' ) ) : ?>

			<a data-src="#vlt-subscribe-popup" href="javascript:;" class="vlt-subscribe-form-toggle">
				<i class="fas fa-bell"></i>
			</a>
			<!-- /.vlt-subscribe-form-toggle -->

		<?php endif; ?>

		<?php if ( $portfolio_link ) : ?>

			<a href="<?php echo esc_url( $portfolio_link ); ?>" class="vlt-btn vlt-btn--primary"><?php esc_html_e( 'Portfolio', 'docs' ); ?></a>
			<!-- /.vlt-btn -->

		<?php endif; ?>

	</header>
	<!-- /.vlt-header--default -->

</div>
<!-- /.hidden-md-down -->