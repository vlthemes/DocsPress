<?php

/**
 * @author: VLThemes
 * @version: 2.0.0
 */

?>

<header class="vlt-page-title">

	<h1><i class="fas fa-folder"></i><?php esc_html_e( 'Changelogs', 'docs' ); ?></h1>

</header>
<!-- /.vlt-page-title -->